<form action="send.php" method="post">
	<input type="text" name="login" placeholder="Введите сообщение-заказ." />
	<input type="text" name="otz" placeholder="Введите адрес" />
	<input type="email" name="email" placeholder="Введите email" required />
	<input type="tel" name="tel" placeholder="Введите телефон" />
	<input type="submit" value="Отправить данные" />
</form>